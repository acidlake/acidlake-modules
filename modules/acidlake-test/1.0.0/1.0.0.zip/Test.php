<?php

namespace Forge\Modules\TestModule;

use Forge\Modules\TestModule\Contracts\TestInterface;

class Test implements TestInterface
{

    public function test(): void
    {
        //
    }

}
