<?php

namespace Forge\Modules\TestModule\Contracts;

interface TestInterface
{
    public function test(): void;
}